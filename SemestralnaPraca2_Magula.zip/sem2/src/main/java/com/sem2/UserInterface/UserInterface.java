package com.sem2.UserInterface;

import com.sem2.SimCore.EventSimulationCore;

public interface UserInterface {
    void refresh(EventSimulationCore simulationCore);
}
