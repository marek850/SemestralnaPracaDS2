package com.sem2.FurnitureCompany.Enums;

public enum EmployeeType {
    A, B, C
}
