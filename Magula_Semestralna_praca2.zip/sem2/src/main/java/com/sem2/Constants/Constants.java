package com.sem2.Constants;

public class Constants {
    public static final double epsilon = 1e-6;
    public static final double REAL_TIME = 1.0;
    public static final double FAST_TIME = 0.5; 
    public static final double MAX_SPEED = 0.0;
}
